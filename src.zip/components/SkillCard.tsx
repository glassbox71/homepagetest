import React from 'react'

const SkillCard = () => {
  return (
    <div>
      
    </div>
  )
}

export default SkillCard
